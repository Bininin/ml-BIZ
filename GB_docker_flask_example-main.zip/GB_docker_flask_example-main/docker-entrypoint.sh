#!/bin/sh


python /app/app/front/run_front_server.py & python /app/app/run_server.py